package com.cg.eam.controller;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.eam.entity.Admin;
import com.cg.eam.entity.Attendance;
import com.cg.eam.entity.Employee;
import com.cg.eam.service.AdminService;
import com.cg.eam.service.AdminStaffService;

@CrossOrigin("http://localhost:4200")
@RestController
public class AdminController {
	@Autowired
	private AdminService service;

	@Autowired
	private AdminStaffService staffService;
	
	@GetMapping(path= "/login",produces="application/json")
	public List<Admin> getAdmin() {
		return service.adminLogin();

	}

	@PostMapping("/add")
	public Employee addEmployee(@RequestBody Employee e) {
		return service.addEmployee(e);

	}
	
	
	@PutMapping("/update/{id}")
	public String updateEmployee(@PathVariable("id") int id,@RequestBody Employee e) {
		return service.updateEmployee(e, id);
	}
	
	
	@PutMapping("/updateAttendance")
	public String updateEmployeeAttendance(@RequestBody Attendance a ) {
		return staffService.updateEmployeeAttendance(a);
	//	return service.updateEmployee(id);
	}
	
	@DeleteMapping("/delete/{id}")
	public String deleteEmployee(@PathVariable int id) {
		return service.deleteEmployee(id);
		
	}
	
	@GetMapping("/getall")
	public List<Employee> employeeList(){
		return service.employeeList();
	}

	@GetMapping("/getById/{id}")
	public Employee employeeDetails(@PathVariable int id) {
		return service.employeeDetails(id);
	}
	
	@PostMapping("/addAdmin")
	public String addAdmin(@RequestBody Admin admin) {
		return service.addAdmin(admin);
	}
}
