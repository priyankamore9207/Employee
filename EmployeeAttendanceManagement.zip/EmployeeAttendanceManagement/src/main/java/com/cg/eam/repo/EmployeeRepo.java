package com.cg.eam.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;


import com.cg.eam.entity.Employee;

public interface EmployeeRepo extends JpaRepository<Employee, Integer> {

	public Optional<Employee> findByUserNameAndPassword(String userName,String password);
}
