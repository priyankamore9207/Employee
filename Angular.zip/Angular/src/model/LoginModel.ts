export class LoginModel{
    userName: String;
    password: String;
}