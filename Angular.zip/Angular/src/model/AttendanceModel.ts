import { Employee } from './Employee';

export class AttendanceModel{
    number: number;
    date: string;
    status: number;
    empId : number;
} 